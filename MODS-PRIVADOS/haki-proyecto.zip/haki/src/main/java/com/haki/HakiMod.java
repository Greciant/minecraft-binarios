package com.haki;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@Mod(HakiMod.MODID)
public class HakiMod {
    public static final String MODID = "haki";

    public HakiMod(IEventBus modBus, ModContainer container) {
        HakiEffects.EFFECTS.register(modBus);
        HakiSounds.SOUNDS.register(modBus);
        modBus.addListener(this::registerPayloads);
        NeoForge.EVENT_BUS.register(HakiServer.class);
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToServer(
            HakiKeyPayload.TYPE, HakiKeyPayload.CODEC, HakiServer::onKey);
    }
}
