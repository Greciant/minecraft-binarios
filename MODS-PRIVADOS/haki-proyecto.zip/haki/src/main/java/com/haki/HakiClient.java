package com.haki;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(modid = HakiMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class HakiClient {
    public static final KeyMapping HAKI_KEY = new KeyMapping(
        "key.haki.king", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, "key.categories.haki");

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(HAKI_KEY);
    }
}
